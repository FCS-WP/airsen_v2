<div class="wrap">
  <h1>General Settings</h1>
  <div id="zippy-root">
    <div id="zippy-settings"></div>

  </div>
</div>
