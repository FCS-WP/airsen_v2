import React from "react";
import AuthContent from "../../Layouts/AuthContent";

const Authentication = () => {
  return (
    <div id="zippy-authentication">
      <AuthContent />
    </div>
  );
};
export default Authentication;
