import React from "react";
import Header from "../Header/Header";
import Content from "../Layouts/Content";
function Dashboard() {
  return (
    <>
      <Header />
      <Content />
    </>
  );
}
export default Dashboard;
